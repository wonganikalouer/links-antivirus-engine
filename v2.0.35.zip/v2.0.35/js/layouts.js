// This contains all app layouts
var AppController=null
var isScanning=false
var FOUND=0
var REGSTATE=false
var _5713="Trial version has expired!"
var _0098=" [Unregistered] Links Antivirus"
var _1113512="Illegal File Transfer"
var _329="day(s) Remaining"
	scanner_layout="<button style=\"padding:0px;\" onclick=\"quickScan()\"><img src='img/quick_scan.png' id='quick_scan' title='Scan Computer'></button><button title='select folder to scan' onclick=\"manual_scan()\">Manual Scan</button><button title='setup when to auto scan' onclick=\"slide('.scan-scheduler','98%',300)\">Schedule Scan</button>"
	optimizer_layout="<button onclick=\"repair_apps()\" style=\"padding:0px;\"><img src='img/optimize.png' id='quick_scan' title='Recover broken apps' ></button><button title='Scan Program Files for Broken Apps'>Quick Optimization</button><button title='Select where you want to optimize'>Manual Optimization</button>"
	statistics_layout="<img src='img/stats.png' id='quick_scan' title='Refresh statistics' onmouseenter=\"slide('.submenu','0px',300)\"><button title='Export to external data' onmouseenter=\"slide('.submenu','300px',300)\">Export </button><button title='Upload to Links Antivirus Online Storage' onmouseenter=\"slide('.submenu','0px',300)\">Upload </button><button title='Clear Data' onclick=\"resetQuarantine()\" onmouseenter=\"slide('.submenu','0px',300)\">Clear</button>"
	settings_layout="<img src='img/settings.png' id='quick_scan' title='Simple settings' ><button title='simple settings'>General Settings</button><button title='user information' onclick=\"view_user_acc()\">User Account</button><button title='pro security features' onclick=\"view_sec_ft()\">Security Features</button><button title='reset settigs to deault' onclick=\'reset_settings()\'>Reset </button>"

//for settings tab