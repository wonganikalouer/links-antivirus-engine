// this is a database and preference file
var DEFAULT_SETTINGS={
	applicationVersion:"2.0.2",
	settingsType:"AI"
}