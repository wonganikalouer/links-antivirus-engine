var preloader=""
var p
var k=0
var page=1
var dtr
var _50,_51
var _v1r05_=0
include("css.animations")
//always put the include function before loading the page, makes the 
//included function faster
function _ready(){
	show()

}

function setup_controller(_A_){
	AppController=_A_
}

function _00012(argument) {
	Toast(argument.getName())
}

function _01010(dtr,urd) {
	if(dtr==-15){
		REGSTATE=true
		var uname=urd.split(".")[0]
		var udate=urd.split(".")[1]
		var utype=urd.split(".")[2]
		Toast("Welcome back "+uname)

		display("reg")
		hide("notReg")
		setValue(".rto",uname)
		setValue(".dtt",udate)
		setValue(".aty",utype)

	}else if(dtr==-404){
		REGSTATE=false
		Toast(_1113512)
		display(".block")
		setBg(".sliding-drawer","rgba(0,0,0,0.9)")
		get(".top").className="top-dark"
		setValue("ui-title",_0098)
		get("ut","white").style.color="white"
	}else if(dtr>0){
		REGSTATE=true
		Toast(dtr+" "+_329)
	}else if(dtr==0 || (dtr<0 && dtr!=15)){
		REGSTATE=false
		display(".block")
		setBg(".sliding-drawer","rgba(0,0,0,0.9)")
		get(".top").className="top-dark"
		setValue("ui-title",_0098)
		get("ut","white").style.color="white"
		Toast(_5713)
	}
}

function _538(_3151) {
	_50=_3151.split(";")[0]
	_51=_3151.split(";")[1]

	if(_50=="1"){
		tbs=true
		setValue(".tb","Turn Off")
		setValue("sfo","Security is on.")
	}else{
		tbs=false
		setValue(".tb","Turn On")	
		setValue("sfo","You're at risk!")
	}
}

function saveThemeColor(argument) {
	var c=getValue("theme_color")
	paintUI(c)
	AppController.saveThemeColor(c)
	Toast("Theme Saved!")
}

function paintUI(c) {
	setBg(".sliding-drawer",c)
	var mh=get(".menu-icon")
	for(var i=0;i<mh.children.length;i++){
		mh.children[i].style.backgroundColor=c	
	}
	get("#ut").setColor(c)
	get(".sc").setBgColor(c)
	get("scan_started_h3").setBgColor(c)
	get(".sc").style.borderColor=c
	setValue("theme_color",c)
}




function view_settings(argument) {
	document.querySelector(".content-panel").style.marginLeft="0px"
	document.querySelector(".scanner").style.width="0%"
	setTransition(".settings","900ms")
	slide(".settings","100%")
	document.querySelector(".stats").style.width="0%"
	document.querySelector(".security_features").style.width="0%"
	preloader=settings_layout
	setValue("path","settings")
	// setValue(".menu-panel",preloader)	
	argument.style.backgroundColor="rgba(0,0,0,0.1)"
	get("#b1").style.backgroundColor="transparent"
	get("#b2").style.backgroundColor="transparent"
	get("#b3").style.backgroundColor="transparent"
	get("#b1").style.borderLeft="0px solid white"
	get("#b2").style.borderLeft="0px solid white"
	get("#b3").style.borderLeft="0px solid white"

	argument.style.borderLeft="3px solid white"
	// slide('.scan-scheduler','0%',900)
	mo=false
			slide(".sliding-drawer","0px",600)
			marginLeft(".menu-icon","0px")
}

function view_scanner(argument) {
	argument.style.borderLeft="3px solid white"
	document.querySelector(".scanner").style.width="100%"
	document.querySelector(".settings").style.width="0%"
	document.querySelector(".stats").style.width="0%"
	document.querySelector(".security_features").style.width="0%"
	// document.querySelector(".menu-panel").style.width="250px"
	document.querySelector(".content-panel").style.marginLeft="0px"
	preloader=scanner_layout
	setValue("path","scanner")
	// setValue(".menu-panel",preloader)
	// var mn=get(".menu-panel").children;
	// loop(0,mn.length-1,function(p){
	// 	mn[p].style.transition="300ms"
	// 	mn[p].style.opacity="1"
	// })
	argument.style.backgroundColor="rgba(0,0,0,0.1)"
	get("#b2").style.backgroundColor="transparent"
	get("#b3").style.backgroundColor="transparent"
	get("#b4").style.backgroundColor="transparent"
	get("#b4").style.borderLeft="0px solid white"
	get("#b2").style.borderLeft="0px solid white"
	get("#b3").style.borderLeft="0px solid white"
	// slide('.scan-scheduler','0%',900)
	mo=false
			slide(".sliding-drawer","0px",600)
			marginLeft(".menu-icon","0px")
}

function view_statistics(argument) {
	argument.style.borderLeft="3px solid white"
	// document.querySelector(".menu-panel").style.width="100px"
	document.querySelector(".content-panel").style.marginLeft="0px"
	document.querySelector(".stats").style.width="100%"
	document.querySelector(".scanner").style.width="00%"
	document.querySelector(".settings").style.width="0%"
	
	document.querySelector(".security_features").style.width="0%"
	preloader=statistics_layout
	setValue("path","statistics")
	// setValue(".menu-panel",preloader)
	argument.style.backgroundColor="rgba(0,0,0,0.1)"
	get("#b1").style.backgroundColor="transparent"
	get("#b2").style.backgroundColor="transparent"
	get("#b4").style.backgroundColor="transparent"
	get("#b1").style.borderLeft="0px solid white"
	get("#b2").style.borderLeft="0px solid white"
	get("#b4").style.borderLeft="0px solid white"
	// slide('.scan-scheduler','0%',900)
	k=0;
	get("#q-data").innerHTML=""
	mo=false
			slide(".sliding-drawer","0px",600)
			marginLeft(".menu-icon","0px")
	AppController.readQuarantine(page)


}
function view_optimizer(argument) {
	argument.style.borderLeft="3px solid white"
	// document.querySelector(".menu-panel").style.width="250px"
	document.querySelector(".content-panel").style.marginLeft="0px"
	document.querySelector(".scanner").style.width="00%"
	document.querySelector(".settings").style.width="0%"
	document.querySelector(".stats").style.width="0%"
	document.querySelector(".security_features").style.width="100%"
	preloader=optimizer_layout
	setValue("path","optimizer")
	// setValue(".menu-panel",preloader)
	// slide(".scan-scheduler","0%",900)
	argument.style.backgroundColor="rgba(0,0,0,0.1)"
	get("#b1").style.backgroundColor="transparent"
	get("#b3").style.backgroundColor="transparent"
	get("#b4").style.backgroundColor="transparent"
	get("#b1").style.borderLeft="0px solid white"
	get("#b4").style.borderLeft="0px solid white"
	get("#b3").style.borderLeft="0px solid white"
	mo=false
			slide(".sliding-drawer","0px",600)
			marginLeft(".menu-icon","0px")
	loadRunningApps()
	//this runs the apps in background
}

function repair_apps(){
	Toast("expect this in the next version",LONG)
}
var reset=0;
function reset_settings(argument) {
	if (reset==0) {
	Toast("click again to reset",MEDIUM)
	reset=1;
	setTimeout(clear_reset,MEDIUM*1000)
}
else{
	//clear_settings_to_default()
	Toast("Settings reset",10)
}
function clear_reset(argument) {
	reset=0;
}
}


function view_sec_ft(argument) {
	setValue(".settings",SECURITY)
}

function view_user_acc(argument) {
	setValue(".settings",REGISTER)
}

function manual_scan(argument) {
	if(!isScanning){
		// AppController.chooseFolder();
	// 
	try{
	setupDrives(AppController.getDrives())
	}catch(err){setupDrives("C=2000-1000,F=56-23")}
}else{
	Toast("Scanning is in Progress ",8)
}
}

var Drive=function(){
	this.name="",
	this.size=0,
	this.availlable=0
}

function setupDrives(object){
	//this will receive an object containing all variables from drives list
	var drives_availlable=object.split(",")
	get(".data").innerHTML=""
	for(var d=0;d<drives_availlable.length;d++){
		var drive=drives_availlable[d];
		var dr=new Drive()
		dr.name=drive.split("=")[0]
		dr.size=drive.split("=")[1].split("-")[0]
		dr.availlable=drive.split("=")[1].split("-")[1]

		var div=create("div")
		div.className="drive"
		div.title="Click to Scan this drive "+dr.name
		var progress_div=create("div")

		progress_div.className="progress_div"
		// do calculations here
		var sizeOutOf100=(dr.availlable/dr.size)*100
		// progress_div.style.width=sizeOutOf100+"%"
		progress_div.slide(sizeOutOf100+"%",600)
		//create proper lable for the drive
		var h3=create("h3")
		h3.innerHTML=dr.name
		h3.className="drive_label"
		progress_div.appendChild(h3)
		// Toast(sizeOutOf100+"%",LONG)
		div.appendChild(progress_div)
		div.onclick=function(){
			// alert("you clicked to scan "+this.children[0].children[0].innerHTML)
			try{
				openFileChooser()
			initialiseScan(this.children[0].children[0].innerHTML)
			Toast("Scanning Started...",LONG);
			isScanning=true;			


			//start animating the scanning icon
			//get(".ts").className="ts-scanning"
		}catch(err){
			//Toast("Please wait a moment...",LONG)
		}
			slide(".file_chooser","0%",300)
			
		}
		set(".data",div)
	}
	
}

// This will get calls from javascript
function updateScanUI(data,p,m){
	setValue(".data-scan",data)
	// setWidth(".the_progress",((p/m)*100)+"%");
	var w=((p/m)*100)+"%"
	w=w.substr(0,4)
	// setValue(".progress_percent",w+" %")
//	var p=innerHTML=((p/m)*100)+""
//	p=p.substr(0,4)+"%";
//	get("progress_indicator").innerHTML=p
}

function resetUI() {
	isScanning=false;
	// get(".progress_bar").style.opacity=0.3
}

function scanCompleted(argument) {
	if (argument>0) {
		Toast("Threats Detected!",LONG)
	}
	isScanning=false
	setWidth(".the_progress","100%");

		setValue(".data-scan","scanning done")
		//clear the interface
		get(".cancel-scan").style.opacity="0.5"
		Toast("Scan is completed",3)
		get("#progress_indicator").style.animation="gsstoprotate 1s linear infinite"
		get("#progress_indicator").style.webkitAnimation="gsstoprotate 1s linear infinite"
}

function loadRunningApps() {
	Toast("loading system apps",MEDIUM)
	//wont allow variables in this file system to avoid uncensored connections
	var systemAppps=AppController.loadSystemApps("50000")
	Toast(systemAppps,5)
}

function cancelscan() {
	if (isScanning) {
		isScanning=false
		Toast("Cancelling scanning...",3)
		get("#progress_indicator").style.animation="gsstoprotate 1s linear infinite"
		get("#progress_indicator").style.webkitAnimation="gsstoprotate 1s linear infinite"
		setWidth(".the_progress","0%");
		setValue(".data-scan","scanning canceled")
		//clear the interface
		get(".cancel-scan").style.opacity="0.5"
		AppController.canelScanning()
		_v1r05_=0;
		setValue(".virus_log",0)

	}else{
		Toast("Links is not scanning.",LONG)
	}
}


function fixFound() {
	if(_v1r05_>0){
		//let java handle the fixing with scan fixer.exe
		AppController.fixAll()
	}else{
		Toast("No viruses found to fix",MEDIUM)
	}
}

function shedule(argument) {
	var el=argument
	try{
	get(".scheduled").appendChild(el)
	Toast(el.innerHTML+" added on schedule",LONG)
	//setup this day into database
	setupShedule(el.innerHTML)
	el.onclick=function(){
		get(".unsheduled").appendChild(this)
		//unsetup this day
		unsetupShedule(el.innerHTML)
		this.onclick=function(){
			shedule(this)
		}
		Toast(this.innerHTML+" removed",LONG)
	}
}catch(err){
	
}
}

function quickScan() {
	// do a quick scan, this will include target folders and locations
	//not too much data
	try{
			AppController.quickScan()
			
			Toast("Quick Scan Started...",LONG);
			isScanning=true;
			get(".progress_bar").style.opacity=1
			setAlpha(".cancel-scan",1)
			
			get("#progress_indicator").style.animation="gsrotate 1s linear infinite"
			get("#progress_indicator").style.webkitAnimation="gsrotate 1s linear infinite"
			//start animating the scanning icon
			//get(".ts").className="ts-scanning"
		}catch(err){
			//Toast("System not ready<br>wait a moment...",LONG)
		}	
		}

function setQuarantine(argument) {
	var limit=15
	var initialPage=0
	
	k++	
	var quarantine=get("#q-data")
	var q=argument.split("<>")
	var layout="<td>"+k+"</td>"+
    	"<td>"+q[0]+"</td>"+
		"<td>"+q[1]+"</td>"+
		"<td>"+q[2]+"</td>"+
		"<td>"+q[3]+"</td>"
		;	
	var row=create("tr")

	row.innerHTML=layout
	quarantine.appendChild(row)
}

function loadPage(p){
	if(p==0 && page>0){
		page--
	}else if(p==1){
		page++
	}
	k=(page)*14;

	get("#q-data").innerHTML=""
	AppController.readQuarantine(page)
}

var resetQ=0;
function resetQuarantine(argument) {
	if (resetQ==0) {
	Toast("click again to reset",MEDIUM)
	resetQ=1;
	setTimeout(clear_reset,MEDIUM*1000)
}
else{
	//clear_settings_to_default()
	Toast("Settings reset",10)
	AppController.resetQuarantine()
}
function clear_reset(argument) {
	resetQ=0;
}
}

function setupShedule(argument) {
	var d=0
	if(argument=="Monday")
	{
		d=1;
	}
	else if (argument=="Tuesday") {
		d=2;
	}
	else if (argument=="Wednsday") {
		d=3;
	}
	else if (argument=="Thursday") {
		d=4;
	}
	else if (argument=="Friday") {
		d=5;
	}
	else if (argument=="Saturday") {
		d=6;
	}
	else if (argument=="Sunday") {
		d=7;
	}
	AppController.setupSchedule(d)
}

function unsetupShedule(argument) {
	var d=0
	if(argument=="Monday")
	{
		d=1;
	}
	else if (argument=="Tuesday") {
		d=2;
	}
	else if (argument=="Wednsday") {
		d=3;
	}
	else if (argument=="Thursday") {
		d=4;
	}
	else if (argument=="Friday") {
		d=5;
	}
	else if (argument=="Saturday") {
		d=6;
	}
	else if (argument=="Sunday") {
		d=7;
	}
	AppController.unsetupSchedule(d)	
}

var pnt=false
function pinTop() {
	
	if(pnt==false){
		pnt=true
		get("#pnt-b").style.background="#ff5e47"
		get("#pnt-b").style.color="white"
	}else{
		pnt=false
		get("#pnt-b").style.background="transparent"
		get("#pnt-b").style.color="#ff5e47"
	}
	AppController.pinTop()
}

var cmode=1
function changeMode(_m0d3) {

	try{
	get(".m"+_m0d3).style.backgroundColor="rgba(50,50,0,0.6)"
	get(".m"+cmode).style.backgroundColor="transparent"

	cmode=_m0d3
}catch(err){
}
	Toast("Settings Updated!")
}

//load secret data from links sacrad directory
function show() {
	if(REGSTATE){
		REGSTATE=true;
	 document.getElementById('reg').style.display="block";
	 hide('notReg')
}
else{
	document.getElementById('notReg').style.display="block";
	document.getElementById('reg').style.display="none";
		REGSTATE=false;
}
}

function register_user() {
		var name=document.getElementById('fName').value;
		var number=document.getElementById('pNumber').value;
		// validating user data
		if (name=="") {
			Toast("Name is empty")
			return
		}
		if (number=="") {
			Toast("Phone numer is empty")
			return
		}
		//this is when the system connects to the internet and creates a url with entered data
		Toast("Please wait...")
		AppController._r(name,number);
	}

	function Purchase() {
				
		hide("bt")
		hide("bt2")
		display("loader-connection")
		marginLeft("loader-connection","320px")
		setAlpha("loader-connection","1")
		Toast("please wait")
		setTimeout(function(){
		try{
			display("otherReg")
		var userReg=getText("fg")
		setValue("user_registration",userReg)
		hide("loader-connection")
		setAlpha("loader-connection",0)
	}catch(err){

	}},3000);

	}
	

	function fb(argument) {
		hide("loader-connection")
		display("bt")
		display("bt2")
		Toast("No internet connections")
	}
var mo
	function openMenu(){
		
		if(mo){
			mo=false
			slide(".sliding-drawer","0px",600)
			marginLeft(".menu-icon","0px")
			
		}else{
			mo=true
			slide(".sliding-drawer","300px",600)
			marginLeft(".menu-icon","300px")
			
		}
	}

	function initialiseScan(argument) {
		// start the scanning process
		if(REGSTATE){
		if(isScanning){
			display("select-folder")
			Toast("Stopping scan")
			marginLeft(".sc","280px")
			marginRight(".sc","280px")
			slide(".scan-details","0px",300)
			setValue(".sc","Scan")
			animate(".sc","scanning-anim 3s linear ")
			setHeight(".file-explorer","200px")
			isScanning=false
			hide("#loader-icon")
		}
			else{
			hide("select-folder")
			marginLeft(".sc","100px")
			marginRight(".sc","100px")
			slide(".scan-details","350px",600)
			setValue(".sc","Stop")
			animate(".sc","scanning-anim 3s linear infinite")
			if(argument==null){
			quickScan()
			}else{
				AppController.scanThisDrive(argument)
			}
			// Toast("Scanning "+argument)
			display("#loader-icon")	
			setHeight(".file-explorer","0px")
			isScanning=true
	}
}else{
	Toast("Unable to start scan<br>This producti is unregistered")
}
	}
	var fca=false
	function openFileChooser(){
		if(isScanning){
			Toast("Scanning is in progress...")
		}
			else{
		if(fca){
			fca=false
			marginTop(".sc","150px")
			marginTop(".button-controls","50px")
			setAlpha(".file-explorer",0)
			
		}else{

			fca=true
			marginTop(".sc","10px")
			marginTop(".button-controls","10px")
			setAlpha(".file-explorer",1)
			manual_scan()
		}
	}
	}

	function scrolling(argument) {
		Toast(argument)
	}
var tbs=true
	function turnOffAgent(){
		if(tbs){
			tbs=false
			// Alert("Your computer will be at risk")
			setValue(".tb","Turn On")
			setValue("sfo","You're at risk!")
			AppController.closeAgent()
			
		}else{
			tbs=true
		setValue(".tb","Turn Off")	
		setValue("sfo","Security is on")
		AppController.openAgent()
		
	}
	}

	function checkUpdates() {
		Toast("<center><h3>Please wait</h3><b>Links is checking internet connection<br>on your machine</b></center>",20)
	}

	function dothis(argument) {
		Toast(argument)
	}

	function ai(a) {

		a.className="on_btn";
		a.value="On";
		get('controlM').className="off_btn";
		get('controlM').value="Off";
		get('notificationM').className="off_btn";
		get('notificationM').value="Off";
		Toast("<img src='img/aimode.png'/><br><br><h2>Artifical Intelligence Mode 1.0</h2><br><b>This setting will grant Links Antivirus the privilage to decide on its own. <br><br>v1.0.0</b>",3,45)
		AppController._5273("1")
	}

		function control(c) {
		
		c.className="on_btn";
		c.value="On";
		get('AiM').className="off_btn";
		get('AiM').value="Off";
		get('notificationM').className="off_btn";
		get('notificationM').value="Off";
		Toast("<img src='img/controlmode.png'/><br><br><h2>Control Mode</h2><br><b>This setting will grant you the privilage to make the decision on the softwares behalf <br><br>v1.0.0</b>",3,45)
		AppController._5273("2")
	}

	function note(n) {
		n.className="on_btn";
		n.value="On";
		get('AiM').className="off_btn";
		get('AiM').value="Off";
		get('controlM').className="off_btn";
		get('controlM').value="Off";
		Toast("<img src='img/notifymode.png'/><br><br><h2>Notification Mode</h2><br><b>This setting will notify you on any changes, threats and other major information changes.<br><br>v1.0.0</b>",5,45)
		AppController._5273("3")
	}
var m=false
function dragStart(argument) {
	m=true
}

function drag(argument) {
	// body...
	m=false
}

function moveMouse(argument) {
	argument.preventDefault()
	if(m){
		var x=argument.screenX
		var widthX=800-x
		marginLeft(".view_threats",x+10)
		setWidth(".view_threats",widthX)
	}
}

var th=false
function viewThreats() {
	// body...
	if(th==true){
		
		th=false
		marginLeft(".view_threats","800px")
		setTimeout(function() {
			// body...
			hide(".threats_holder")
		},600)

	}else{
		th=true
		display(".threats_holder")
		setTimeout(function() {
			// body...
			marginLeft(".view_threats","400px")
		},100)
		
	}

}

function _2n5ert_(_v_,_n_,_a_) {
	_v1r05_++
	setValue("voutput",_v1r05_)
	var tr=create("tr")
	var l=create("td")
	var n=create("td")
	
	l.innerHTML=_v_
	n.innerHTML=_n_
	tr.title=_a_
	tr.appendChild(n)
	tr.appendChild(l)
	tr.appendChild(a)

	get(".virus_log").appendChild(tr)
}

function deleteThis(argument) {
	var l=tr.children[1].innerHTML
	
	Toast("Threat Removed!")
	get(".virus_log").removeChild(tr)
	AppController.deleteSingle(l)
}

function howToRegister(argument) {
	marginLeft("user_registration","10px")
	marginRight("user_registration","0px")
	setWidth("user_registration","390px")
	marginLeft("f0rm","10px")
	marginRight("f0rm","0px")
	setWidth("f0rm","780px")
	setAlpha("htr",1)
}